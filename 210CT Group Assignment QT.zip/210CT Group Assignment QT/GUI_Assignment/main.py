# importing the required libraries
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from ui.mainwindow import Ui_mainwindow


class mainWindow(QMainWindow, Ui_mainwindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # hide the labels
        self.lbBookingDetails.setHidden(True)
        self.lbDate.setHidden(True)
        self.lbDays.setHidden(True)
        self.lbPerson.setHidden(True)
        self.lbInOut_2.setHidden(True)
        self.lbDestination.setHidden(True)
        self.lbAddOn.setHidden(True)
        self.lbAccomodation_2.setHidden(True)
        self.lbFlight_2.setHidden(True)
        self.lbTotalAmount.setHidden(True)
        self.lbTotalDiscount.setHidden(True)
        self.lbNetAmount.setHidden(True)

        # connection between a signal and a slot
        self.cbInOut.currentTextChanged.connect(self.updateDestination)
        self.cbDestination.currentTextChanged.connect(self.update_flightArrangement)
        self.cbInOut.currentTextChanged.connect(self.checkday)
        self.cbAddOn.stateChanged.connect(self.add_on_services)
        self.sbNoOfDays.valueChanged.connect(self.accommodation)
        self.cbInOut.currentTextChanged.connect(self.flight)
        self.btnConfirm.clicked.connect(self.confirmbtn)

        # adding list of items to InBound/Outbound combo box
        self.cbInOut.addItems(('Inbound', 'Outbound'))

    # to create dependant combo boxes
    # adding list of items of Inbound and Outbound to Destination combo box
    def updateDestination(self, text):
        self.cbDestination.clear()
        if text == 'Inbound':
            self.cbDestination.addItems(('Melaka, Malaysia', 'Langkawi, Kedah Malaysia', 'Penang, Malaysia'))

        elif text == 'Outbound':
            self.cbDestination.addItems(('Bali, Indonesia', 'Bangkok, Thailand'))

    # adding list of items of Destination to Flight Arrangement combo box
    def update_flightArrangement(self, text):
        self.FlightArrangement.clear()
        if text == 'Melaka, Malaysia':
            self.FlightArrangement.addItem('Not Applicable')

        elif text == 'Langkawi, Kedah Malaysia':
            self.FlightArrangement.addItem('Not Applicable')

        elif text == 'Penang, Malaysia':
            self.FlightArrangement.addItem('Not Applicable')

        elif text == 'Bali, Indonesia':
            self.FlightArrangement.addItems(('KL->Indonesia->KL', 'None'))

        elif text == 'Bangkok, Thailand':
            self.FlightArrangement.addItems(('KL->Thailand->KL', 'None'))

    # check condition of Outbound and display error message if condition is incorrect
    def checkday(self):
        if self.cbInOut.currentText() == 'Outbound' and self.sbNoOfDays.value() < 3:
            self.sbNoOfDays.setMinimum(3)  # set requirement of Outbound
            QMessageBox.warning(
                self,
                "Error",
                "Outbound travel requires a minimum of 3 days",
                QMessageBox.Ok|QMessageBox.Cancel)

        else:
            self.sbNoOfDays.setMinimum(0)

    # check if the check box of Add On Services is checked
    # if yes, set visibility status of the labels and check boxes to True
    # if no, set visibility status of the labels and check boxes to False
    def add_on_services(self):
        if self.cbAddOn.isChecked():
            self.lbAccomodation.setVisible(True)
            self.Accomodation.setVisible(True)
            self.lbFlight.setVisible(True)
            self.FlightArrangement.setVisible(True)

        else:
            self.lbAccomodation.setVisible(False)
            self.Accomodation.setVisible(False)
            self.lbFlight.setVisible(False)
            self.FlightArrangement.setVisible(False)

    # check condition of Accommodation
    # if condition is correct, enable the combo box
    # if incorrect, disable the combo box
    def accommodation(self):
        if self.sbNoOfDays.value() > 1:
            self.Accomodation.setEnabled(True)

        else:
            self.Accomodation.setDisabled(True)

    # when Inbound is chosen, flight arrangement combo box will be disabled
    def flight(self):
        if self.cbInOut.currentText() == 'Inbound':
            self.FlightArrangement.setEnabled(False)

        else:
            self.FlightArrangement.setEnabled(True)

    # confirmation message box will be asked when the confirm button is clicked
    def confirmbtn(self):
        reply = QMessageBox.question(
            self,
            "Booking Confirmation",
            "Are you sure you want to confirm your booking? ",
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)

        if reply == QMessageBox.Yes:
            self.booking_details()

    # check if contents are correct and display them
    def booking_details(self):
        # display error message box when the number of Day and Person are incorrect
        if self.sbNoOfDays.value() == 0:
            QMessageBox.warning(
                self,
                "Error",
                "Please select the number of days",
                QMessageBox.Ok | QMessageBox.Cancel)

        elif self.sbNoOfPerson.value() == 0:
                QMessageBox.warning(
                    self,
                    "Error",
                    "Please select the number of person",
                    QMessageBox.Ok | QMessageBox.Cancel)

        else:
            # display of correct contents
            self.lbBookingDetails.setHidden(False)
            self.lbDate.setHidden(False)
            self.lbDate.setText('Travel Date: ' + str(self.dateEdit.date().toPyDate()))
            self.lbDays.setHidden(False)
            self.lbDays.setText('Number of Day(s): ' + str(self.sbNoOfDays.value()))
            self.lbPerson.setHidden(False)
            self.lbPerson.setText('Number of Person(s): ' + str(self.sbNoOfPerson.value()))
            self.lbInOut_2.setHidden(False)
            self.lbInOut_2.setText('Inbound/Outbound: ' + str(self.cbInOut.currentText()))
            self.lbDestination.setHidden(False)
            self.lbDestination.setText('Destination: ' + str(self.cbDestination.currentText()))
            self.lbAddOn.setHidden(False)
            self.lbAddOn.setText('Add On Services: ' + str(self.cbAddOn.isChecked()))
            self.lbAccomodation_2.setHidden(False)
            self.lbFlight_2.setHidden(False)

            if self.cbAddOn.isChecked() == False:
                self.lbAccomodation_2.setText('Accommodation: None')
                self.lbFlight_2.setText('Flight Arrangement: None')

            else:
                self.lbAccomodation_2.setText('Accommodation: ' + str(self.Accomodation.currentText()))
                self.lbFlight_2.setText('Flight Arrangement: ' + str(self.FlightArrangement.currentText()))

            if self.sbNoOfDays.value() <= 1:
                self.lbAccomodation_2.setText('Accommodation: Not Applicable')

            self.lbTotalAmount.setHidden(False)
            self.lbTotalDiscount.setHidden(False)
            self.lbNetAmount.setHidden(False)
            self.calculation(self)

    # calculation of total amount, total discount and net amount to be paid
    def calculation(self, total):
        # calculate total amount
        if self.cbAddOn.isChecked() == True:
            if self.FlightArrangement.currentText() == 'KL->Thailand->KL':
                if self.Accomodation.currentText() == '2 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 80 *\
                            (self.sbNoOfDays.value() - 1) + 1000 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == '3 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 120 *\
                            (self.sbNoOfDays.value() - 1) + 1000 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == '4 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 180 *\
                            (self.sbNoOfDays.value() - 1) + 1000 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == '5 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 250 *\
                            (self.sbNoOfDays.value() - 1) + 1000 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == 'None':
                    total = 200 * self.sbNoOfDays.value() + 1000 * self.sbNoOfPerson.value()

            elif self.FlightArrangement.currentText() == 'KL->Indonesia->KL':
                if self.Accomodation.currentText() == '2 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 80 *\
                            (self.sbNoOfDays.value() - 1) + 1100 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == '3 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 120 *\
                            (self.sbNoOfDays.value() - 1) + 1100 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == '4 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 180 *\
                            (self.sbNoOfDays.value() - 1) + 1100 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == '5 star hotel':
                    total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 250 *\
                            (self.sbNoOfDays.value() - 1) + 1100 * self.sbNoOfPerson.value()
                elif self.Accomodation.currentText() == 'None':
                    total = 200 * self.sbNoOfDays.value() + 1100 * self.sbNoOfPerson.value()

            else:
                if self.cbInOut.currentText() == 'Outbound':
                    if self.Accomodation.currentText() == '2 star hotel':
                        total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 80 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == '3 star hotel':
                        total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 120 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == '4 star hotel':
                        total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 180 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == '5 star hotel':
                        total = 200 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 250 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == 'None':
                        total = 200 * self.sbNoOfDays.value()

                elif self.cbInOut.currentText() == 'Inbound':
                    if self.Accomodation.currentText() == '2 star hotel':
                        total = 120 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 80 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == '3 star hotel':
                        total = 120 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 120 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == '4 star hotel':
                        total = 120 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 180 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == '5 star hotel':
                        total = 120 * self.sbNoOfDays.value() + self.sbNoOfPerson.value() * 250 *\
                                (self.sbNoOfDays.value() - 1)
                    elif self.Accomodation.currentText() == 'None':
                        total = 120 * self.sbNoOfDays.value()

        elif self.cbAddOn.isChecked() == False:
            if self.cbInOut.currentText() == 'Outbound':
                total = 200 * self.sbNoOfDays.value()

            elif self.cbInOut.currentText() == 'Inbound':
                total = 120 * self.sbNoOfDays.value()

        self.lbTotalAmount.setText('Total Amount: RM' + (str(total)))

        # calculate the discounted amount and amount after discount
        if self.sbNoOfPerson.value() > 5:
            discount = total * 0.1
            net_amount = total * 0.9
            self.lbTotalDiscount.setText('Total Discount: RM' + str(discount))
            self.lbNetAmount.setText('Net Amount To Be Paid: RM' + str(net_amount))

        else:
            self.lbTotalDiscount.setText('Total Discount: Not Entitled')
            self.lbNetAmount.setText('Net Amount To Be Paid: RM' + str(total))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mw = mainWindow()
    mw.setWindowTitle('Tour Booking System')
    mw.show()
    app.exec()
